directoryTreeOfFunFiles
=======================

A mixtures of different file types (including some excellent eBooks and audio podcasts) 
for a Python tutorial.

These files are either originals or are believed to be freely distributable.
