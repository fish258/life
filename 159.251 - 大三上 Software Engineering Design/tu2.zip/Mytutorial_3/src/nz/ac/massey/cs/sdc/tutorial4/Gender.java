package nz.ac.massey.cs.sdc.tutorial4;

public enum Gender {
	MALE,FEMALE
}
