package nz.ac.massey.cs.sdc.tutorial7;

public enum Gender {
	MALE,FEMALE
}
