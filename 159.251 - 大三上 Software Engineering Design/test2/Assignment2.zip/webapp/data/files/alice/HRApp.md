# HRApp
## Tasks
[ ] Meet client due:2018-10-20
[ ] Email meeting notes
[ ] Write requirements document due:2018-10-30
