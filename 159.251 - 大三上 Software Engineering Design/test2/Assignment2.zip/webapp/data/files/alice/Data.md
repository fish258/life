# Data
## Tasks
[X] (A) Clean data due:2018-08-10
[ ] (A) Create database due:2018-09-01
[ ] (A) Import data due:2018-09-02
