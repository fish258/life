package test.nz.ac.massey.cs.sdc.jaxb;

import static org.junit.Assert.*;
import java.io.File;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import nz.ac.massey.cs.sdc.jaxb.*;
import org.junit.Test;

/**
 * Test whether the jaxb-generated parser works correctly. 
 * Run this with junit. 
 * @author jens dietrich
 */
public class TestParser {

	@Test
	public void test() throws Exception {
		JAXBContext jc = JAXBContext.newInstance( "nz.ac.massey.cs.sdc.jaxb" );
		Unmarshaller parser = jc.createUnmarshaller();
		File file = new File("email1.xml");
		Email mail = (Email) parser.unmarshal(file);
		
		assertEquals(1,mail.getTo().size());
		Participant to = mail.getTo().get(0);
		assertEquals("jens@massey.ac.nz",to.getEmailAddress());
		assertEquals("Jens Dietrich",to.getDisplayName());
		
		assertEquals(1,mail.getCc().size());
		Participant cc = mail.getCc().get(0);
		assertEquals("students159251_2012@massey.ac.nz",cc.getEmailAddress());
		assertEquals("159.251 2012 student list",cc.getDisplayName());
		
		assertEquals(0,mail.getBcc().size());
		
		assertEquals("update",mail.getSubject());
		assertEquals("this lecture notes have been updated",mail.getBody());
		
	}

}
