# script to generated the API classes
# to see this in action, delete package nz.ac.massey.cs.sdc.jaxb first
xjc -d src -p nz.ac.massey.cs.sdc.jaxb email.xsd