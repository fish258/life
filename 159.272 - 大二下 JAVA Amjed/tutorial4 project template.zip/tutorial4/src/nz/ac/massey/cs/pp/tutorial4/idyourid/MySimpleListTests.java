package nz.ac.massey.cs.pp.tutorial4.idyourid;

import static org.junit.Assert.*;

import nz.ac.massey.cs.pp.tutorial4.SimpleList;
import nz.ac.massey.cs.pp.tutorial4.SimpleListTests;

import org.junit.Before;
import org.junit.Test;

public class MySimpleListTests extends SimpleListTests {
	@Before 
	public void setup() {
		this.list =  new MySimpleList();
	}
}
