package nz.ac.massey.cs.pp.tutorial4;

public class ElementNotFoundException extends Exception {

	public ElementNotFoundException() {
		super("Element not found");
	}


	public ElementNotFoundException(String message) {
		super(message);
	}




}
