package nz.ac.massey.cs.pp.tutorial4.idyourid;

import nz.ac.massey.cs.pp.tutorial4.ElementNotFoundException;
import nz.ac.massey.cs.pp.tutorial4.SimpleList;

/**
 * This is the class template you must implement. This means to replace all TODOs 
 * by meaningful code until all tests in MySimpleTests succeed. 
 * RULES:
 * 1. are not allowed to change the definition of the single instance variable
 * 2. you are not allowed to add instance variables
 */
public class MySimpleList implements SimpleList{
	
	// do not change the next line!! 
	private String[] content = new String[5];
	// do not addd more instance variables

	@Override
	public void add(String element) {
		// TODO 
	}

	@Override
	public void remove(String element) throws ElementNotFoundException {
		// TODO 
	}

	@Override
	public int getSize() {
		// TODO 
		return 0;
	}

	@Override
	public boolean contains(String element) {
		// TODO
		return false;
	}

		
}
